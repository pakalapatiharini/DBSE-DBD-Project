import mysql from "mysql2/promise";
import dotenv from "dotenv";

dotenv.config();

export const pool = mysql.createPool({
  host: process.env.DB_HOST || "localhost",
  port: Number(process.env.DB_PORT || 3306),
  user: process.env.DB_USER || "root",
  password: process.env.DB_PASSWORD || "",
  database: process.env.DB_NAME || "raktasetu",
  waitForConnections: true,
  connectionLimit: 10,
  // Return DATE/DATETIME as strings so the API can format them exactly
  // like the frontend already expects ("2025-09-11", "2025-09-11T08:40:00").
  dateStrings: true,
});

// Fail fast with a helpful message if MySQL isn't reachable.
export async function checkDb() {
  const conn = await pool.getConnection();
  try {
    await conn.ping();
  } finally {
    conn.release();
  }
}
