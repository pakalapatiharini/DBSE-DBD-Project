import { useState } from "react";
import { PageHeader, Card, Badge } from "../../components/UI";
import { useApi, api } from "../../lib/api";
import { timeAgo } from "../../lib/utils";

export default function AdminAlerts() {
  const { data: emergencyAlerts, error, reload } = useApi(api.getAlerts);
  const [resolving, setResolving] = useState(null);

  if (error) return <p className="empty-state">Couldn&apos;t load alerts.</p>;
  if (!emergencyAlerts) return <p className="empty-state">Loading alerts…</p>;

  async function resolve(id) {
    setResolving(id);
    try {
      await api.resolveAlert(id);
      reload();
    } finally {
      setResolving(null);
    }
  }

  return (
    <div>
      <PageHeader title="Emergency alerts" subtitle="Critical stock levels and time-sensitive requests, in one feed." />
      {emergencyAlerts.length === 0 && (
        <Card><p className="empty-state">No active alerts. All clear.</p></Card>
      )}
      {emergencyAlerts.map((a) => (
        <Card key={a.id}>
          <div style={{ display: "flex", justifyContent: "space-between", alignItems: "flex-start", gap: "1rem" }}>
            <div>
              <Badge>{a.severity}</Badge>
              <div style={{ fontWeight: 600, marginTop: "0.5rem" }}>{a.type}</div>
              <p style={{ marginTop: "0.3rem", color: "var(--ink-soft)", fontSize: "0.9rem" }}>{a.detail}</p>
            </div>
            <div style={{ display: "flex", flexDirection: "column", alignItems: "flex-end", gap: "0.5rem", flexShrink: 0 }}>
              <span style={{ fontSize: "0.78rem", color: "var(--ink-soft)", whiteSpace: "nowrap" }}>{timeAgo(a.raisedAt)}</span>
              <button className="btn btn--ghost" onClick={() => resolve(a.id)} disabled={resolving === a.id}>
                {resolving === a.id ? "Resolving…" : "Resolve"}
              </button>
            </div>
          </div>
        </Card>
      ))}
    </div>
  );
}
